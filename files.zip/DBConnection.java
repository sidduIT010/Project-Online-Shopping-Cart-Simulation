import java.sql.*;

public class DBConnection {

    // ─── Change these to match your MySQL setup ───────────────────────────────
    private static final String URL      = "jdbc:mysql://localhost:3306/shopping_cart"
                                         + "?useSSL=false&allowPublicKeyRetrieval=true"
                                         + "&serverTimezone=UTC";
    private static final String USERNAME = "root";      // your MySQL username
    private static final String PASSWORD = "root";      // your MySQL password
    // ─────────────────────────────────────────────────────────────────────────

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found: " + e.getMessage());
        }
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try { conn.close(); } catch (SQLException ignored) {}
        }
    }

    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        try { if (rs   != null) rs.close();   } catch (SQLException ignored) {}
        try { if (stmt != null) stmt.close(); } catch (SQLException ignored) {}
        closeConnection(conn);
    }
}
