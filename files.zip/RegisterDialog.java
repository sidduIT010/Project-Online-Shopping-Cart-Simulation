import javax.swing.*;
import java.awt.*;

public class RegisterDialog extends JDialog {
    private UserDAO userDAO;

    public RegisterDialog(JFrame parent, UserDAO userDAO) {
        super(parent, "Register", true);
        this.userDAO = userDAO;
        setSize(350, 300);
        setLocationRelativeTo(parent);
        buildUI();
        setVisible(true);
    }

    private void buildUI() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20,30,20,30));
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5,0,5,0);
        gbc.gridx = 0; gbc.gridy = 0;

        JLabel title = new JLabel("Create Account");
        title.setFont(new Font("Georgia", Font.BOLD, 18));
        title.setForeground(new Color(30,40,60));
        panel.add(title, gbc);

        gbc.gridy++;
        JTextField unField = new JTextField(15);
        unField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY),
            BorderFactory.createEmptyBorder(5,8,5,8)));
        JLabel unLabel = new JLabel("Username:");
        unLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        panel.add(unLabel, gbc);
        gbc.gridy++;
        panel.add(unField, gbc);

        gbc.gridy++;
        JLabel pwLabel = new JLabel("Password:");
        pwLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        panel.add(pwLabel, gbc);
        gbc.gridy++;
        JPasswordField pwField = new JPasswordField(15);
        pwField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY),
            BorderFactory.createEmptyBorder(5,8,5,8)));
        panel.add(pwField, gbc);

        gbc.gridy++;
        JLabel emLabel = new JLabel("Email:");
        emLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        panel.add(emLabel, gbc);
        gbc.gridy++;
        JTextField emField = new JTextField(15);
        emField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY),
            BorderFactory.createEmptyBorder(5,8,5,8)));
        panel.add(emField, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(15,0,5,0);
        JButton regBtn = new JButton("Register");
        regBtn.setBackground(new Color(255,165,0));
        regBtn.setForeground(Color.WHITE);
        regBtn.setFont(new Font("Arial", Font.BOLD, 13));
        regBtn.setFocusPainted(false);
        regBtn.setBorderPainted(false);
        regBtn.addActionListener(e -> {
            String un = unField.getText().trim();
            String pw = new String(pwField.getPassword());
            String em = emField.getText().trim();
            if (un.isEmpty() || pw.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Username and password required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (userDAO.registerUser(un, pw, em, un)) {
                JOptionPane.showMessageDialog(this, "Registration successful! Please login.", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Registration failed. Username may be taken.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(regBtn, gbc);
        add(panel);
    }
}
