import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {

    private JTextField     usernameField;
    private JPasswordField passwordField;
    private UserDAO        userDAO = new UserDAO();

    public LoginFrame() {
        setTitle("Online Shopping Cart");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 350);
        setLocationRelativeTo(null);
        setResizable(false);
        buildUI();
        setVisible(true);
    }

    private void buildUI() {
        // Dark blue outer panel
        JPanel outer = new JPanel(new GridBagLayout());
        outer.setBackground(new Color(30, 40, 60));
        setContentPane(outer);

        // White inner card
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        card.setPreferredSize(new Dimension(290, 220));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;

        // Title
        JLabel title = new JLabel("Login");
        title.setFont(new Font("Georgia", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 60));
        card.add(title, gbc);

        // Username
        gbc.gridy++;
        usernameField = new JTextField(15);
        styleTextField(usernameField, "Username");
        card.add(usernameField, gbc);

        // Password
        gbc.gridy++;
        passwordField = new JPasswordField(15);
        styleTextField(passwordField, "Password");
        card.add(passwordField, gbc);

        // Login button
        gbc.gridy++;
        gbc.insets = new Insets(10, 0, 5, 0);
        JButton loginBtn = new JButton("Login");
        loginBtn.setBackground(new Color(255, 165, 0));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFont(new Font("Arial", Font.BOLD, 14));
        loginBtn.setFocusPainted(false);
        loginBtn.setBorderPainted(false);
        loginBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginBtn.setPreferredSize(new Dimension(200, 35));
        loginBtn.addActionListener(e -> doLogin());
        card.add(loginBtn, gbc);

        // Register link
        gbc.gridy++;
        gbc.insets = new Insets(2, 0, 0, 0);
        JLabel reg = new JLabel("New user? Register here");
        reg.setForeground(new Color(0, 100, 200));
        reg.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        reg.setFont(new Font("Arial", Font.PLAIN, 11));
        reg.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { openRegister(); }
        });
        card.add(reg, gbc);

        // Enter key
        getRootPane().setDefaultButton(loginBtn);

        outer.add(card);
    }

    private void styleTextField(JTextField f, String placeholder) {
        f.setFont(new Font("Arial", Font.PLAIN, 13));
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)));
        f.setForeground(Color.GRAY);
        f.setText(placeholder);
        f.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (f.getText().equals(placeholder)) {
                    f.setText(""); f.setForeground(Color.BLACK);
                    if (f instanceof JPasswordField)
                        ((JPasswordField)f).setEchoChar('•');
                }
            }
            public void focusLost(FocusEvent e) {
                if (f.getText().isEmpty()) {
                    f.setText(placeholder); f.setForeground(Color.GRAY);
                    if (f instanceof JPasswordField)
                        ((JPasswordField)f).setEchoChar((char)0);
                }
            }
        });
        if (f instanceof JPasswordField)
            ((JPasswordField)f).setEchoChar((char)0);
    }

    private void doLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        if (username.equals("Username") || username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter username.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (password.equals("Password") || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter password.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int[] result = userDAO.authenticate(username, password);
        if (result != null) {
            dispose();
            new MainWindow(result[0], username);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openRegister() {
        new RegisterDialog(this, userDAO);
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
        SwingUtilities.invokeLater(LoginFrame::new);
    }
}
